﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Net.Https;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace NWS_Alert_Integration
{
	#region Delegates
	public delegate void DelegateFn(ushort index, SimplSharpString areaDesc, SimplSharpString onset,
		SimplSharpString ends, SimplSharpString messageType, SimplSharpString event_desc, SimplSharpString severity, SimplSharpString certainty, 
		SimplSharpString response, SimplSharpString headline, SimplSharpString instruction);

	public delegate void DelegateFn1(ushort count);
	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class NWS_Alert
	{

		public DelegateFn callback_fn { get; set; }
		public DelegateFn1 callback_fn1 { get; set; }

		#region Declarations
		private string Latitude;
		private string Longitude;
		private static Debug_Options Debug;
		private const int MAX_ALERTS = 10;
		#endregion

		public NWS_Alert()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialization
		// 
		//****************************************************************************************
		public void Initialize(string Latitude, string Longitude, short Debug)
		{
			#region Save Parameters
			this.Latitude = Latitude;
			this.Longitude = Longitude;
			#endregion

			Set_Debug_Message_Output(Debug);

			Debug_Message("Initialize", "SUCCESS");
		}

		//****************************************************************************************
		// 
		//  Poll	-	Poll for NWS Alert
		// 
		//****************************************************************************************
		public void Poll()
		{
			HttpsClient client = null;
			int i;
			string url = "";

			Debug_Message("Poll", "Start");

			#region Error Checking
			if (string.IsNullOrEmpty(Latitude))
			{
				string err = "NWS_Alert - Poll - NWS_Zone Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion

			#region Create url
			url = "https://api.weather.gov/alerts/active?point=" + Latitude + "," + Longitude;
			Debug_Message("Poll", "url = " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				client = new HttpsClient();
				client.Verbose = true;
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.Header.SetHeaderValue("Accept", "text/html");
				request.Header.SetHeaderValue("Accept-Language", "en-US,en;q=0.9");
				//request.Header.SetHeaderValue("Accept-Encoding", "gzip");
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64");
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "NWS_Alert - Poll - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					Debug_Message("Poll", "ContentString = " + response.ContentString);

					if (response.ContentString.IndexOf("\"features\": [],") == -1)
					{
						Alert_Info Alert = JsonConvert.DeserializeObject<Alert_Info>(response.ContentString);
						i = 0;

						foreach (Feature f in Alert.features)
						{
							Debug_Message("Poll", "areaDesc = " + f.properties.areaDesc);
							Debug_Message("Poll", "onset = " + f.properties.onset);
							Debug_Message("Poll", "ends = " + f.properties.ends);
							Debug_Message("Poll", "messageType = " + f.properties.messageType);
							Debug_Message("Poll", "event = " + f.properties.@event);
							Debug_Message("Poll", "severity = " + f.properties.severity);
							Debug_Message("Poll", "certainty = " + f.properties.certainty);
							Debug_Message("Poll", "response = " + f.properties.response);
							Debug_Message("Poll", "headline = " + f.properties.headline);
							Debug_Message("Poll", "instruction = " + f.properties.instruction);

							callback_fn(Convert.ToUInt16(i + 1), f.properties.areaDesc, f.properties.onset.ToString(), f.properties.ends.ToString(),
								f.properties.messageType, f.properties.@event, f.properties.severity, f.properties.certainty, f.properties.response, 
								f.properties.headline, f.properties.instruction);

							i++;

							if (i >= MAX_ALERTS)
							{
								break;
							}
						}
						callback_fn1(Convert.ToUInt16(Alert.features.Count));//report that done sending alerts
					}
					else
					{
						callback_fn1(Convert.ToUInt16(0));//report that done sending alerts
					}
				}
			}
			catch (Exception e)
			{
				string err = "NWS_Alert - Poll - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					NWS_Alert.Debug = Debug_Options.None;
					break;

				case 1:
					NWS_Alert.Debug = Debug_Options.Console;
					break;

				case 2:
					NWS_Alert.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					NWS_Alert.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 200;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("NWS_Alert - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("NWS_Alert - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}

	public class Feature
	{
		public string id { get; set; }
		public string type { get; set; }
		public object geometry { get; set; }
		public Properties properties { get; set; }
	}

	public class Geocode
	{
		public List<string> SAME { get; set; }
		public List<string> UGC { get; set; }
	}

	public class Parameters
	{
		public List<string> AWIPSidentifier { get; set; }
		public List<string> WMOidentifier { get; set; }
		public List<string> NWSheadline { get; set; }
		public List<string> BLOCKCHANNEL { get; set; }

		[JsonProperty("EAS-ORG")]
		public List<string> EASORG { get; set; }
		public List<string> VTEC { get; set; }
		public List<DateTime> eventEndingTime { get; set; }
	}

	public class Properties
	{
		[JsonProperty("@id")]
		public string at_id { get; set; }

		[JsonProperty("@type")]
		public string at_type { get; set; }
		public string id { get; set; }
		public string areaDesc { get; set; }
		public Geocode geocode { get; set; }
		public List<string> affectedZones { get; set; }
		public List<object> references { get; set; }
		public DateTime sent { get; set; }
		public DateTime effective { get; set; }
		public DateTime onset { get; set; }
		public DateTime expires { get; set; }
		public DateTime ends { get; set; }
		public string status { get; set; }
		public string messageType { get; set; }
		public string category { get; set; }
		public string severity { get; set; }
		public string certainty { get; set; }
		public string urgency { get; set; }
		public string @event { get; set; }
		public string sender { get; set; }
		public string senderName { get; set; }
		public string headline { get; set; }
		public string description { get; set; }
		public string instruction { get; set; }
		public string response { get; set; }
		public Parameters parameters { get; set; }
	}

	public class Alert_Info
	{
		[JsonProperty("@context")]
		public List<object> context { get; set; }
		public string type { get; set; }
		public List<Feature> features { get; set; }
		public string title { get; set; }
		public DateTime updated { get; set; }
	}
}
