﻿using System.Reflection;

[assembly: AssemblyTitle("NWS_Alert")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("NWS_Alert")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2023")]
[assembly: AssemblyVersion("1.0.0.*")]

